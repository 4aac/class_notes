#!/bin/bash

IMAGE_NAME="gria-abia2425"

# Build
docker build -t ${IMAGE_NAME} .

